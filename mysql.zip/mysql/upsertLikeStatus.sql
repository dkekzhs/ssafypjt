CREATE DEFINER=`ssafy`@`localhost` PROCEDURE `upsertLikeStatus`(IN p_article_no INT, IN p_user_id VARCHAR(16), IN p_like_status INT)
BEGIN
    DECLARE exist_like_status INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- 오류 발생 시 롤백하고 -1 반환
        ROLLBACK;
        SELECT -1;
    END;

    START TRANSACTION;

    SELECT like_status INTO exist_like_status 
    FROM board_like 
    WHERE article_no = p_article_no AND user_id = p_user_id;

    IF exist_like_status IS NULL THEN
        INSERT INTO board_like (article_no, user_id, like_status) 
        VALUES (p_article_no, p_user_id, p_like_status);
    ELSEIF exist_like_status = p_like_status THEN
        DELETE FROM board_like WHERE article_no = p_article_no AND user_id = p_user_id;
    ELSE
        UPDATE board_like 
        SET like_status = p_like_status 
        WHERE article_no = p_article_no AND user_id = p_user_id;
    END IF;

    -- 모든 작업이 성공하면 커밋하고 0 반환
    COMMIT;
    SELECT 0;
END