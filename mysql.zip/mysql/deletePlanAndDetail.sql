CREATE DEFINER=`ssafy`@`localhost` PROCEDURE `deletePlanAndDetails`(IN p_user_id VARCHAR(255), IN p_plan_id INT)
BEGIN
    -- plan_board에서 특정 계획 삭제
    DELETE FROM plan_board
    WHERE user_id = p_user_id AND plan_id = p_plan_id;

    -- plan_detail에서 해당 계획의 모든 세부 정보 삭제
    DELETE FROM plan_detail
    WHERE plan_id = p_plan_id;

    -- share에서 해당 계획의 모든 공유 정보 삭제
    DELETE FROM share
    WHERE plan_id = p_plan_id;
END