CREATE DEFINER=`ssafy`@`localhost` PROCEDURE `CreatePlanBoardWithShare`(
    IN p_user_id VARCHAR(16),
    IN p_share_flag INT,
    IN p_share_data JSON,
    IN p_plan_name VARCHAR(45)
)
BEGIN
	declare last_plan_id INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- 오류 발생 시 롤백하고 -1 반환
        ROLLBACK;
        SELECT -1;
    END;
    -- 트랜잭션 시작
    START TRANSACTION;
    -- Insert into plan_board table
    INSERT INTO plan_board (user_id, share_flag,plan_name)
    VALUES (p_user_id, p_share_flag, p_plan_name);
    SET last_plan_id = LAST_INSERT_ID();
    
    -- Check share_flag value
    CASE p_share_flag
        WHEN 1 THEN
            -- 친구 공개일 경우, 친구 목록에서 status가 1인 친구를 찾아 share 테이블에 추가
            INSERT INTO share (plan_id, share_user_id)
            SELECT last_plan_id, f.to
            FROM friend f 
            WHERE (f.from = p_user_id OR f.to = p_user_id) AND f.status = 1;
        WHEN 2 THEN
            -- JSON 데이터에서 share_user_id 추출
            INSERT INTO share (plan_id, share_user_id)
            SELECT last_plan_id, jt.share_user_id
            FROM JSON_TABLE(
                p_share_data,
                '$[*]' COLUMNS(
                    share_user_id VARCHAR(16) PATH '$'
                )
            ) AS jt;
	ELSE

    DO 0;
    END CASE;
	select last_plan_id as plan_id ;
    -- 트랜잭션 커밋
    COMMIT;
END