CREATE DEFINER=`ssafy`@`localhost` PROCEDURE `GetArticleLikesAndStatus`(IN p_article_no INT, IN p_user_id VARCHAR(20))
BEGIN
  SELECT 
    (SELECT COUNT(*) FROM board_like WHERE article_no = p_article_no AND like_status = 1) AS like_count,
    (SELECT COUNT(*) FROM board_like WHERE article_no = p_article_no AND like_status = 0) AS dislike_count,
    (SELECT like_status FROM board_like WHERE article_no = p_article_no AND user_id = p_user_id) AS like_status;
END